package mobile.automation.Screens;

import org.openqa.selenium.WebElement;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import mobile.automation.pages.cmdsandgestures.ScreenActions;
import mobile.automation.pages.cmdsandgestures.DeviceCommands;
import mobile.automation.pages.cmdsandgestures.AndroidGestureJS;
import mobile.automation.pages.cmdsandgestures.DeviceCommands;

public class AnimationMenuScreen extends ScreenActions {
	
	@AndroidFindBy(accessibility = "Bouncing Balls")
    @iOSXCUITFindBy(accessibility = "Bouncing Balls")
    private WebElement bouncingBalls;
	
	@AndroidFindBy(accessibility = "Cloning")
    @iOSXCUITFindBy(accessibility = "Cloning")
    private WebElement cloning;
	
	public boolean isAnimationMenuScreenDisplayed() {
	    return isElementDisplayed(bouncingBalls) && isElementDisplayed(cloning);
	}
	
	public MenuScreen clickOnAnimation() {
		//click(animation, "animation");
		navigateBack();
		return new MenuScreen();
	}
	
	
    

	
	

}
