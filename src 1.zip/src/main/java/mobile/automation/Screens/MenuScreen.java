package mobile.automation.Screens;

import org.openqa.selenium.WebElement;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import mobile.automation.pages.cmdsandgestures.ScreenActions;
import mobile.automation.pages.cmdsandgestures.DeviceCommands;
import mobile.automation.pages.cmdsandgestures.AndroidGestureJS;
import mobile.automation.pages.cmdsandgestures.DeviceCommands;

public class MenuScreen extends ScreenActions {
	
	@AndroidFindBy(accessibility = "Animation")
    @iOSXCUITFindBy(accessibility = "Animation")
    private WebElement animation;
	
	public boolean isMenuScreenDisplayed() {
	    return isElementDisplayed(animation);
	}
	
	public AnimationMenuScreen clickOnAnimation() {
		click(animation, "animation");
		return new AnimationMenuScreen();
	}
	
	
	
	
    

	
	

}
