package mobile.automation.enums;

public enum CategoryType {

  REGRESSION, SANITY, SMOKE
}
