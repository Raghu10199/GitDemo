package mobile.automation.enums;

public enum MobilePlatformName {

  ANDROID,
  ANDROID_WEB,
  IOS,
  IOS_WEB
}
