package mobile.automation.enums;

public enum WaitStrategy {
  CLICKABLE, PRESENCE, VISIBLE, NONE
}
