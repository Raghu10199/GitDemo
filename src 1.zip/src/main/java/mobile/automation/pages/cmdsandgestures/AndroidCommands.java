package mobile.automation.pages.cmdsandgestures;

import mobile.automation.driver.manager.DriverManager;
import mobile.automation.reports.ExtentReportLogger;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.Activity;
import io.appium.java_client.android.AndroidDriver;
//import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.SupportsRotation;

import java.time.Duration;

import org.openqa.selenium.ScreenOrientation;

import com.google.common.collect.ImmutableMap;
//import io.appium.java_client.MobileElement;

public class AndroidCommands {
	
	AndroidDriver androidDriver= (AndroidDriver) DriverManager.getDriver();
	
	public void getServerStatus() {
	    DriverManager.getDriver().getStatus();
	}
	
	public void setOrientation(ScreenOrientation screenOrientationType) {
	    switch (screenOrientationType) {
	      case LANDSCAPE:
	    	androidDriver.rotate(ScreenOrientation.LANDSCAPE);
	        ExtentReportLogger.logInfo("Device Orientation is set to Landscape");
	        break;
	      case PORTRAIT:
	    	androidDriver.rotate(ScreenOrientation.PORTRAIT);
	        ExtentReportLogger.logInfo("Device Orientation is set to Portrait");
	        break;
	      default:
	        throw new IllegalStateException("Unexpected value in Screen Orientation: " + screenOrientationType);
	    }
	}
	
	private SupportsRotation AndroidDriver(AppiumDriver driver) {
		// TODO Auto-generated method stub
		return null;
	}

	public void backgroundApp() {
	   androidDriver.runAppInBackground(Duration.ofSeconds(10));
	   ExtentReportLogger.logInfo("Running App in background for 10 seconds");
	}
	
	
	public void openNotifications() {
		androidDriver.openNotifications();
		ExtentReportLogger.logInfo("Notification is opened");
	}
	
	public void runAppInBackground(int seconds) {
		androidDriver.runAppInBackground(Duration.ofSeconds(seconds));
		ExtentReportLogger.logInfo("App is running in background for " + seconds + " seconds");
	}
	
	public void runAppInBackgroundPermanent() {
		androidDriver.runAppInBackground(Duration.ofSeconds(-1));
		ExtentReportLogger.logInfo("App is running in background permanently");
	}
	
	@SuppressWarnings("deprecation")
	public void resetApp() {
		androidDriver.resetApp();
		ExtentReportLogger.logInfo("App is reset");
	}
	
	public void activateApp(String bundleId) {
		androidDriver.activateApp(bundleId);
		ExtentReportLogger.logInfo("App is reset");
	}
	
	public void terminateApp(String bundleId) {
		androidDriver.terminateApp(bundleId);
		ExtentReportLogger.logInfo("App is terminated");
	}
	
	@SuppressWarnings("deprecation")
	public void closeApp() {
		androidDriver.closeApp();
		ExtentReportLogger.logInfo("App is closed");
	}
	
	@SuppressWarnings("deprecation")
	public void launchApp() {
		androidDriver.launchApp();
		ExtentReportLogger.logInfo("App is launched");
	}
	
	public void installApp(String apkPath) {
		androidDriver.installApp(apkPath);
		ExtentReportLogger.logInfo("App is installed");
		
	}
	
	public void removeApp(String bundleId) {
		androidDriver.removeApp(bundleId);
		ExtentReportLogger.logInfo("App is removed");
	}
	
	public void isAppInstalled(String bundleId) {
		androidDriver.isAppInstalled(bundleId);
		ExtentReportLogger.logInfo("App is installed");
	}
	
	public String appstatusCheck(String bundleId) {
		ExtentReportLogger.logInfo("Verifying the app status - closed/opened/backgrounded/terminated");
		return androidDriver.queryAppState(bundleId).toString();
		
	}
	
	public void startActivityAndroid(String appPackage, String appActivity) {
		androidDriver.startActivity(new Activity(appPackage, appActivity));
		ExtentReportLogger.logInfo("Activity is started");
	}
	
	public String getCurrentActivityAndroid() {
		ExtentReportLogger.logInfo("Get the current Activity of the app");
		return androidDriver.currentActivity().toString();
		
	}
	
	public String getCurrentPackageAndroid() {
		ExtentReportLogger.logInfo("Get the current Package of the app");
		return androidDriver.getCurrentPackage().toString();

	}
	
	
	
	
	
	
	
	

}
