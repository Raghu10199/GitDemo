package mobile.automation.pages.cmdsandgestures;

import mobile.automation.driver.manager.DriverManager;
import mobile.automation.enums.ConfigJson;
import mobile.automation.reports.ExtentReportLogger;

import java.io.InputStreamReader;

import static mobile.automation.utils.configloader.JsonUtils.getConfig;

import java.io.BufferedReader;
import java.io.IOException;
import java.time.Duration;

import io.appium.java_client.HidesKeyboard;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.connection.ConnectionStateBuilder;
import io.appium.java_client.android.connection.HasNetworkConnection;

public class DeviceCommands {
	
	public void hideKeyboard() {
		((HidesKeyboard) DriverManager.getDriver()).hideKeyboard();	    
	    ExtentReportLogger.logInfo("Keyboard is hidden");
	}
	
	public void rotateDevice() {
		//DriverManager.getDriver().rotate(Duration.ofSeconds(2));
		ExtentReportLogger.logInfo("Device is rotated");
	}
	
	
	private static void executeAdbCommand(String deviceId, String command) throws IOException, InterruptedException {
		
		String adbCommand = (deviceId == null) ? "adb shell " + command : "adb -s "+ deviceId+ " shell " +command;
		Process process = Runtime.getRuntime().exec(adbCommand);
		process.waitFor();
		
		//check for any error during command execution
		try(BufferedReader errorReader = new BufferedReader(new InputStreamReader(process.getErrorStream()))){
			String errorLine;
			while((errorLine = errorReader.readLine()) !=null) {
				System.err.println("Error:"+errorLine );
				ExtentReportLogger.logInfo("Error:"+errorLine);
			}
		}
	}
	
	
	public static void openDeviceSettings(String deviceId) throws IOException, InterruptedException {
		executeAdbCommand(deviceId,getConfig(ConfigJson.OPEN_SETTINGS));
		ExtentReportLogger.logInfo("Device Settings is opened");
	}
	
	public static void lockDevice(String deviceId) throws IOException, InterruptedException {
		executeAdbCommand(deviceId,getConfig(ConfigJson.LOCK_DEVICE));
	}
	
	public static void unlockDevice(String deviceId) throws IOException, InterruptedException {
		executeAdbCommand(deviceId,getConfig(ConfigJson.UNLOCK_DEVICE));
	}
	
	public static void enableSleepMode(String deviceId) throws IOException, InterruptedException {
		executeAdbCommand(deviceId,getConfig(ConfigJson.SLEEP_DEVICE));
	}
	
	public static void enableBlueTooth(String deviceId) throws IOException, InterruptedException {
		executeAdbCommand(deviceId,getConfig(ConfigJson.ENABLE_BLUETOOTH));
	}
	
	public static void disableBlueTooth(String deviceId) throws IOException, InterruptedException {
		executeAdbCommand(deviceId, getConfig(ConfigJson.DISABLE_BLUETOOTH));
	}
	
	public static void enableGPS(String deviceId) throws IOException, InterruptedException {
		executeAdbCommand(deviceId, getConfig(ConfigJson.ENABLE_GPS));
	}
	
	public static void disableGPS(String deviceId) throws IOException, InterruptedException {
		executeAdbCommand(deviceId, getConfig(ConfigJson.DISABLE_GPS));
	}
	
	public static void enableAirplaneModeUsingIntent(String deviceId) throws IOException, InterruptedException {
		executeAdbCommand(deviceId, getConfig(ConfigJson.ENABLE_AIRPLANE_MODE));
		executeAdbCommand(deviceId, getConfig(ConfigJson.BROADCAST_INTENT_AIRPLANEMODE_ON));
	}
	
	public static void disableAirplaneModeUsingIntent(String deviceId) throws IOException, InterruptedException {
		executeAdbCommand(deviceId, getConfig(ConfigJson.DISABLE_AIRPLANE_MODE));
		executeAdbCommand(deviceId, getConfig(ConfigJson.BROADCAST_INTENT_AIRPLANEMODE_OFF));
	}
	
	public static void disableAutoDateTimeSettings(String deviceId) throws IOException, InterruptedException {
		executeAdbCommand(deviceId, getConfig(ConfigJson.DISABLE_AUTO_DATETIME_SETTINGS));
	}
	
	public static void disableAutoTimeZone(String deviceId) throws IOException, InterruptedException {
		executeAdbCommand(deviceId, getConfig(ConfigJson.DISABLE_AUTO_TIME_ZONE));
	}
	
	public static void enableAutoDateTimeSettings(String deviceId) throws IOException, InterruptedException {
		executeAdbCommand(deviceId, getConfig(ConfigJson.ENABLE_AUTO_DATETIME_SETTINGS));
	}
	
	public static void enableAutoTimeZone(String deviceId) throws IOException, InterruptedException {
		executeAdbCommand(deviceId, getConfig(ConfigJson.ENABLE_AUTO_TIME_ZONE));
	}
	
	public static void enableWifi(String deviceId) throws IOException, InterruptedException {
		((HasNetworkConnection) DriverManager.getDriver()).setConnection(new ConnectionStateBuilder().withWiFiEnabled().build());
	}
	
	public static void disableWifi(String deviceId) throws IOException, InterruptedException {
		((HasNetworkConnection) DriverManager.getDriver())
				.setConnection(new ConnectionStateBuilder().withWiFiDisabled().build());
	}
	
	public static void enableData(String deviceId) throws IOException, InterruptedException {
		((HasNetworkConnection) DriverManager.getDriver())
				.setConnection(new ConnectionStateBuilder().withDataEnabled().build());
	}
	
	public static void disableData(String deviceId) throws IOException, InterruptedException {
		((HasNetworkConnection) DriverManager.getDriver())
				.setConnection(new ConnectionStateBuilder().withDataDisabled().build());
	}
	
	
	
}
