package mobile.automation.test;

import java.io.IOException;

import org.testng.annotations.Test;
import mobile.automation.driver.factory.DriverFactory;
import mobile.automation.enums.MobilePlatformName;
import mobile.automation.pages.cmdsandgestures.DeviceCommands;
import mobile.automation.utils.AppiumServerManager;

public class RunAppium {
	
	@Test
	public void runAppium() throws IOException, InterruptedException {
		
		AppiumServerManager.startAppiumServer();
		DriverFactory.initializeDriver(MobilePlatformName.ANDROID, "Medium Phone API 35", "emulator-5556", 8201, "no");
		AppiumServerManager.stopAppiumServer();
		//getInstance().getDriver(MobilePlatformName.ANDROID);
		//DeviceCommands.unlockDevice("emulator-5556");
		
	}
	
	

}
