package mobile.automation.Screens;

import java.util.List;

import org.openqa.selenium.WebElement;

import io.appium.java_client.pagefactory.AndroidFindAll;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AndroidFindBys;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import mobile.automation.pages.cmdsandgestures.ScreenActions;
import mobile.automation.reports.ExtentReportLogger;
import mobile.automation.pages.cmdsandgestures.DeviceCommands;
import mobile.automation.enums.MobileFindBy;
import mobile.automation.pages.cmdsandgestures.AndroidGestureJS;
import mobile.automation.pages.cmdsandgestures.DeviceCommands;

public class ProductsScreen extends ScreenActions {
	
    @AndroidFindBy(xpath = "//android.widget.ImageButton[@resource-id=\"com.androidsample.generalstore:id/appbar_btn_cart\"]\r\n" + "")
    //@iOSXCUITFindBy(id = "com.androidsample.generalstore:id/appbar_btn_cart")
    private WebElement cartbtn;
    
    
    public boolean isProductDisplayed(String productName) {    	
    	boolean isProductDisplayed = false;
    	List<WebElement> products = getDynamicMobileElements("//android.widget.TextView[@resource-id=\"com.androidsample.generalstore:id/productName\" and @text=\""+productName+"\"]\r\n"
    			+ "", MobileFindBy.XPATH);
    	for (WebElement product : products) {
    		if (product.getText().equalsIgnoreCase(productName)) {
    			isProductDisplayed = true;
    			break;
    		}
    	}
    	return isProductDisplayed;
    }
    
	public void clickCart() {
		click(cartbtn, "Cart Button");
	}
	
	public boolean addProductToCart(String productName) {
		boolean isProductAdded = false;
		int productCount = 0;
		List<WebElement> products = getDynamicMobileElements("//android.widget.TextView[@resource-id=\"com.androidsample.generalstore:id/productName\" and @text=\""+productName+"\"]\r\n"
    			+ "", MobileFindBy.XPATH);
		List<WebElement> addToCart = getDynamicMobileElements("//android.widget.TextView[@text='ADD TO CART']\r\n" + "", MobileFindBy.XPATH);
		for (WebElement product : products) {
			
			if (product.getText().equalsIgnoreCase(productName)) {				
				click(addToCart.get(productCount), "Add to Cart");
				isProductAdded = true;
				break;
			}
			productCount++;
		}
		return isProductAdded;
	}
    
	/*
	public void swipeToElementAndClick(String elementName) {
		swipeToElementAndClick(elementName);
		
	}
	
	*/
}
