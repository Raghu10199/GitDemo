package mobile.automation.Screens;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.iOSXCUITFindBy;
import mobile.automation.pages.cmdsandgestures.ScreenActions;
import mobile.automation.reports.ExtentReportLogger;
import mobile.automation.pages.cmdsandgestures.DeviceCommands;
import mobile.automation.driver.manager.DriverManager;
import mobile.automation.enums.MobileFindBy;
import mobile.automation.pages.cmdsandgestures.AndroidGestureJS;
import mobile.automation.pages.cmdsandgestures.DeviceCommands;

public class SignUpScreen extends ScreenActions {
	
	

	@AndroidFindBy(id = "com.androidsample.generalstore:id/toolbar_title")
	//@iOSXCUITFindBy(id = "com.androidsample.generalstore:id/toolbar_title")
	private WebElement toolbar_title;
	
	@AndroidFindBy(id = "com.androidsample.generalstore:id/spinnerCountry")
	//@iOSXCUITFindBy(id = "com.androidsample.generalstore:id/spinnerCountry")
	private WebElement spinnerCountry;	
	
	@AndroidFindBy(id = "com.androidsample.generalstore:id/nameField")
	//@iOSXCUITFindBy(id = "com.androidsample.generalstore:id/nameField")
	private WebElement nameField;
	
	@AndroidFindBy(id = "com.androidsample.generalstore:id/radioMale")
	//@iOSXCUITFindBy(id = "com.androidsample.generalstore:id/radioMale")
	private WebElement radioMale;
	
	@AndroidFindBy(id = "com.androidsample.generalstore:id/radioFemale")
	//@iOSXCUITFindBy(id = "com.androidsample.generalstore:id/radioFemale")
	private WebElement radioFemale;
	
	@AndroidFindBy(id = "com.androidsample.generalstore:id/btnLetsShop")
	//@iOSXCUITFindBy(id = "com.androidsample.generalstore:id/btnLetsShop")
	private WebElement btnLetsShop;
	
	public SignUpScreen() {
		super();
		//PageFactory.initElements(DriverManager.getDriver(), this);
	}

	public boolean isSignUpScreenDisplayed() {
		return isElementDisplayed(toolbar_title) && isElementDisplayed(spinnerCountry) && 
				isElementDisplayed(nameField) && isElementDisplayed(radioMale)
				&& isElementDisplayed(radioFemale) && isElementDisplayed(btnLetsShop);
	}
	
	public void selectCountry(String country) {
		click(spinnerCountry, "spinnerCountry");
		WebElement cntry= getDynamicMobileElement("//android.widget.TextView[@resource-id=\"android:id/text1\" and @text=\""+country+"\"]\r\n"+ "",MobileFindBy.XPATH);
		scrollToElement(cntry);
		click(cntry, country);
	}
	
	public void enterName(String name) {
		enterText(nameField, name, "nameField");
	}
	
	public void selectGender(String gender) {
		if(gender.equalsIgnoreCase("female") && !isElementSelected(radioFemale))
            click(radioFemale, "radioFemale");
        else if(gender.equalsIgnoreCase("male") && !isElementSelected(radioMale))
        	click(radioMale, "radioMale");
        else
        	ExtentReportLogger.logFail("Not a proper value for gender", null);
			click(radioMale, "radioMale");
		
    }
	
	public void clickLetsShop() {
		
		click(btnLetsShop, "btnLetsShop");
    }

}
