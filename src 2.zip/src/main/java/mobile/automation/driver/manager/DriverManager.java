package mobile.automation.driver.manager;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;


import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.openqa.selenium.WebElement;

import java.util.Objects;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class DriverManager {
	


  private static final ThreadLocal<AppiumDriver> threadLocalDriver = new ThreadLocal<>();

  public static AppiumDriver getDriver() {
    return threadLocalDriver.get();
  }

  public static void setAppiumDriver(AppiumDriver driver) {
    if (Objects.nonNull(driver))
      threadLocalDriver.set(driver);
  }

  public static void unload() {
    threadLocalDriver.remove();
  }
  
  
}
