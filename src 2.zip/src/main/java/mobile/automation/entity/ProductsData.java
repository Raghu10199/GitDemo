package mobile.automation.entity;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder(setterPrefix = "set")
public class ProductsData {

  private String productName;
}
