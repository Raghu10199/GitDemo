package mobile.automation.enums;

public enum MobileBrowserName {
  CHROME,
  SAFARI
}
