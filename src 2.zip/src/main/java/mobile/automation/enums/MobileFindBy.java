package mobile.automation.enums;

public enum MobileFindBy {
  XPATH, CSS, ID, CLASS, ACCESSIBILITY_ID , RESOURCE_ID
}
