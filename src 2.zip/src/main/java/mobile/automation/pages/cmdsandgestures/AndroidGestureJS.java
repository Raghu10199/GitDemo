package mobile.automation.pages.cmdsandgestures;

import mobile.automation.driver.manager.DriverManager;
import com.google.common.collect.ImmutableMap;
//import io.appium.java_client.MobileElement;

import io.appium.java_client.android.AndroidDriver;
//import io.appium.java_client.android.AndroidElement;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.remote.RemoteWebElement;


public class AndroidGestureJS {
	
	AndroidDriver driver = (AndroidDriver) DriverManager.getDriver();
	
	public void clickGesture(WebElement element)	{
		
		driver.executeScript("mobile: clickGesture", ImmutableMap.of(
			    "elementId", ((RemoteWebElement) element).getId()
			));
	}
	
	public void doubleClickGesture(WebElement element)	{
		((JavascriptExecutor) driver).executeScript("mobile: doubleClickGesture", ImmutableMap.of(
			    "elementId", ((RemoteWebElement) element).getId()
			));
	}
	
	public void longClickGesture(WebElement element)	{
		((JavascriptExecutor)driver).executeScript("mobile: longClickGesture",
				ImmutableMap.of("elementId",((RemoteWebElement)element).getId(),
						"duration",2000));
	}
		
	public void dragGesture(WebElement element, int xOffset, int yOffset) {
		((JavascriptExecutor) driver).executeScript("mobile: dragGesture", ImmutableMap.of("elementId",
				((RemoteWebElement) element).getId(), "xOffset", xOffset, "yOffset", yOffset));
	}
	
	public void flingGesture(WebElement element, String direction, int speed) {
		((JavascriptExecutor) driver).executeScript("mobile: flingGesture", ImmutableMap.of("elementId",
				((RemoteWebElement) element).getId(), "direction", direction, "speed", speed));
		
	}
	
	public void pinchOpenGesture(WebElement element, float percent) {
		((JavascriptExecutor) driver).executeScript("mobile: pinchOpenGesture",
				ImmutableMap.of("elementId", ((RemoteWebElement) element).getId(), "percent", percent));
	}
	
	public void pinchCloseGesture(WebElement element, float percent) {
		((JavascriptExecutor) driver).executeScript("mobile: pinchCloseGesture",
				ImmutableMap.of("elementId", ((RemoteWebElement) element).getId(), "percent", percent));
	}
	
	
	public void swipeGesture(WebElement element, int left, int width, int height, float percent) {
		((JavascriptExecutor) driver).executeScript("mobile: swipeGesture", 
				ImmutableMap.of("left", left, "top", 100,"width", width, "height", height,
						"direction", "left", "percent", percent));		
	}
	
	
	public void scrollGesture(WebElement element, int left, int width, int height, float percent) {
		((JavascriptExecutor) driver).executeScript("mobile: scrollGesture", 
				ImmutableMap.of("left", left, "top", 100,"width", width, "height", height,
						"direction", "left", "percent", percent));		
	}
	
	
}
