package mobile.automation.pages.cmdsandgestures;

import mobile.automation.driver.manager.DriverManager;
import mobile.automation.enums.ConfigJson;
import mobile.automation.reports.ExtentReportLogger;

import java.io.InputStreamReader;

import static mobile.automation.utils.configloader.JsonUtils.getConfig;

import java.io.BufferedReader;
import java.io.IOException;
import java.time.Duration;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import io.appium.java_client.HidesKeyboard;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.connection.ConnectionStateBuilder;
import io.appium.java_client.android.connection.HasNetworkConnection;

public class DeviceCommands {
	
	public void hideKeyboard() {
		((HidesKeyboard) DriverManager.getDriver()).hideKeyboard();	    
	    ExtentReportLogger.logInfo("Keyboard is hidden");
	}
	
	public void rotateDevice() {
		//DriverManager.getDriver().rotate(Duration.ofSeconds(2));
		ExtentReportLogger.logInfo("Device is rotated");
	}
	
	
	private static String executeAdbCommand(String deviceId, String command) throws IOException, InterruptedException {
		
		String adbCommand = (deviceId == null) ? "adb shell " + command : "adb -s "+ deviceId+ " shell " +command;
		Process process = Runtime.getRuntime().exec(adbCommand);
		process.waitFor();
		
		StringBuilder output = new StringBuilder();
		try(BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))){
			String line;
			while((line = reader.readLine()) != null) {
				output.append(line).append("\n");
			}
		}
		
		//check for any error during command execution
		try(BufferedReader errorReader = new BufferedReader(new InputStreamReader(process.getErrorStream()))){
			String errorLine;
			while((errorLine = errorReader.readLine()) !=null) {
				System.err.println("Error:"+errorLine );
				ExtentReportLogger.logInfo("Error:"+errorLine);
			}
		}
		return output.toString();
	}
	
	public static void openDeviceSettings(String deviceId) throws IOException, InterruptedException {
		executeAdbCommand(deviceId,getConfig(ConfigJson.OPEN_SETTINGS));
		ExtentReportLogger.logInfo("Device Settings is opened");
	}
	
	public static void lockDevice(String deviceId) throws IOException, InterruptedException {
		executeAdbCommand(deviceId,getConfig(ConfigJson.LOCK_DEVICE));
	}
	
	public static void unlockDevice(String deviceId, String passcode) throws IOException, InterruptedException {
		//Turn on the screen
		executeAdbCommand(deviceId,getConfig(ConfigJson.UNLOCK_DEVICE));
		
		//Unlock the device(swipe up if no passcode, else enter passcode)
				if(passcode == null || passcode.isEmpty()) {
					executeAdbCommand(deviceId, getConfig(ConfigJson.SWIPE_UP_TO_UNLOCK));
				}else {
					//Enter passcode
					for(char digit : passcode.toCharArray()) {
						executeAdbCommand(deviceId, getConfig(ConfigJson.ENTER_PASSCODE) + digit);
						Thread.sleep(500);
					}
					//Press 'Enter' after passcode
					executeAdbCommand(deviceId, getConfig(ConfigJson.PRESS_ENTER_KEY));
				}
	}
	
	public static void enableSleepMode(String deviceId) throws IOException, InterruptedException {
		executeAdbCommand(deviceId,getConfig(ConfigJson.SLEEP_DEVICE));
	}
	
	public static void disableSleepMode(String deviceId) throws IOException, InterruptedException {
		executeAdbCommand(deviceId,getConfig(ConfigJson.UNLOCK_DEVICE));
		executeAdbCommand(deviceId, getConfig(ConfigJson.DISABLE_SLEEP_MODE));
	}
	
	public static void enableBlueTooth(String deviceId) throws IOException, InterruptedException {
		executeAdbCommand(deviceId,getConfig(ConfigJson.ENABLE_BLUETOOTH));
		Thread.sleep(2000);
		//Allow popup for enable bluetooth
//		executeAdbCommand(deviceId, getConfig(ConfigJson.ENTER_KEYEVENT));
		//If above keyevent doesn't work then tap with coordinates
		executeAdbCommand(deviceId, getConfig(ConfigJson.ALLOW_POPUP));
	}
	
	public static void setGpsEnabled(String deviceId, boolean enable) throws IOException, InterruptedException {
		String locationCommand = enable ?
				getConfig(ConfigJson.ENABLE_GPS) : 	getConfig(ConfigJson.DISABLE_GPS);
		executeAdbCommand(deviceId , locationCommand);			
	}
	
	public static void setAirplaneMode(String deviceId, boolean enable) throws IOException, InterruptedException {
		String modeCommand = enable ? getConfig(ConfigJson.ENABLE_AIRPLANE_MODE) : 
			getConfig(ConfigJson.DISABLE_AIRPLANE_MODE);
		executeAdbCommand(deviceId, modeCommand);

	}
	
	public static void disableBlueTooth(String deviceId) throws IOException, InterruptedException {
		executeAdbCommand(deviceId, getConfig(ConfigJson.DISABLE_BLUETOOTH));
	}
	
	public static void enableGPS(String deviceId) throws IOException, InterruptedException {
		executeAdbCommand(deviceId, getConfig(ConfigJson.ENABLE_GPS));
	}
	
	public static void disableGPS(String deviceId) throws IOException, InterruptedException {
		executeAdbCommand(deviceId, getConfig(ConfigJson.DISABLE_GPS));
	}
	
	public static void enableAirplaneModeUsingIntent(String deviceId) throws IOException, InterruptedException {
		executeAdbCommand(deviceId, getConfig(ConfigJson.ENABLE_AIRPLANE_MODE));
		executeAdbCommand(deviceId, getConfig(ConfigJson.BROADCAST_INTENT_AIRPLANEMODE_ON));
	}
	
	public static void disableAirplaneModeUsingIntent(String deviceId) throws IOException, InterruptedException {
		executeAdbCommand(deviceId, getConfig(ConfigJson.DISABLE_AIRPLANE_MODE));
		executeAdbCommand(deviceId, getConfig(ConfigJson.BROADCAST_INTENT_AIRPLANEMODE_OFF));
	}
	
	public static void disableAutoDateTimeSettings(String deviceId) throws IOException, InterruptedException {
		executeAdbCommand(deviceId, getConfig(ConfigJson.DISABLE_AUTO_DATETIME_SETTINGS));
	}
	
	public static void disableAutoTimeZone(String deviceId) throws IOException, InterruptedException {
		executeAdbCommand(deviceId, getConfig(ConfigJson.DISABLE_AUTO_TIME_ZONE));
	}
	
	public static void enableAutoDateTimeSettings(String deviceId) throws IOException, InterruptedException {
		executeAdbCommand(deviceId, getConfig(ConfigJson.ENABLE_AUTO_DATETIME_SETTINGS));
	}
	
	public static void enableAutoTimeZone(String deviceId) throws IOException, InterruptedException {
		executeAdbCommand(deviceId, getConfig(ConfigJson.ENABLE_AUTO_TIME_ZONE));
	}
	
	public static void enableWifi(String deviceId) throws IOException, InterruptedException {
		((HasNetworkConnection) DriverManager.getDriver()).setConnection(new ConnectionStateBuilder().withWiFiEnabled().build());
	}
	
	public static void disableWifi(String deviceId) throws IOException, InterruptedException {
		((HasNetworkConnection) DriverManager.getDriver())
				.setConnection(new ConnectionStateBuilder().withWiFiDisabled().build());
	}
	
	public static void enableData(String deviceId) throws IOException, InterruptedException {
		((HasNetworkConnection) DriverManager.getDriver())
				.setConnection(new ConnectionStateBuilder().withDataEnabled().build());
	}
	
	public static void disableData(String deviceId) throws IOException, InterruptedException {
		((HasNetworkConnection) DriverManager.getDriver())
				.setConnection(new ConnectionStateBuilder().withDataDisabled().build());
	}
	
	public static String getSoftwareVersion(String deviceId) throws IOException, InterruptedException {
		return executeAdbCommand(deviceId, getConfig(ConfigJson.GET_SOFTWARE_VERSION));
	}
	
	public static void openNotificationTray(String deviceId) throws IOException, InterruptedException {
		executeAdbCommand(deviceId, getConfig(ConfigJson.OPEN_NOTIFICATION_TRAY));
	}
	public static void openFirstNotification(String deviceId) throws IOException, InterruptedException {
		executeAdbCommand(deviceId, getConfig(ConfigJson.OPEN_FIRST_NOTIFICATION));
	}
	public static void expandFirstNotification(String deviceId) throws IOException, InterruptedException {
		executeAdbCommand(deviceId, getConfig(ConfigJson.EXPAND_FIRST_NOTIFICATION));
	}
	public static void dismissFirstNotification(String deviceId) throws IOException, InterruptedException {
		executeAdbCommand(deviceId, getConfig(ConfigJson.DISMISS_FIRST_NOTIFICATION));
	}
	public static void handleNotification(String deviceId, String passcode) throws IOException, InterruptedException {
		//Ensure device is unlocked
		if(passcode != null && !passcode.isEmpty()) {
			unlockDevice(deviceId, passcode);
		}else {
			unlockDevice(deviceId, null);
		}
		//Open notification tray
		openNotificationTray(deviceId);
		//Expand, Open, or dismiss notification as required
		expandFirstNotification(deviceId);
	}
	
	public static String getDeviceIMEI(String deviceId) throws IOException, InterruptedException {
		//Execute the command to get IMEI
		String output = executeAdbCommand(deviceId, getConfig(ConfigJson.GET_DEVICE_IMEI_ID));
		
		// Parse the IMEI from output if it's segment in hexadecimal format
		Pattern hexaPattern = Pattern.compile("0x(\\d+)");
		Matcher matcher = hexaPattern.matcher(output);
		
		StringBuilder imeiBuilder = new StringBuilder();
		while (matcher.find()) {
			String segment = matcher.group(1);
			imeiBuilder.append(Integer.parseInt(segment));
		}
		
		//Return the IMEI or null if parsing fails
		String imei = imeiBuilder.toString();
		return imei.isEmpty() ? null : imei;	
	}
	
	
}
