package mobile.automation.pages.cmdsandgestures;

import mobile.automation.driver.manager.DriverManager;
import mobile.automation.enums.MobileFindBy;
import mobile.automation.enums.WaitStrategy;
import mobile.automation.reports.ExtentReportLogger;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Ordering;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.HidesKeyboard;
//import io.appium.java_client.MobileElement;
import io.appium.java_client.MultiTouchAction;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.PowerACState;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import io.appium.java_client.touch.TapOptions;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.ElementOption;
import io.appium.java_client.touch.offset.PointOption;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Keys;
import org.openqa.selenium.ScreenOrientation;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.Pause;
import org.openqa.selenium.interactions.PointerInput;
import org.openqa.selenium.interactions.Sequence;
import org.openqa.selenium.remote.RemoteWebElement;

import java.net.MalformedURLException;
//import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.support.PageFactory;

import java.time.Duration;
import java.util.Arrays;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import static mobile.automation.enums.MobileFindBy.ACCESSIBILITY_ID;
import static mobile.automation.enums.MobileFindBy.CLASS;
import static mobile.automation.enums.MobileFindBy.CSS;
import static mobile.automation.enums.MobileFindBy.ID;
//import static mobile.automation.enums.MobileFindBy.NAME;
import static mobile.automation.enums.MobileFindBy.XPATH;
import static mobile.automation.wait.WaitFactory.*;
import static mobile.automation.enums.MobileFindBy.RESOURCE_ID;

public class ScreenActions {


	public final Map<MobileFindBy, Function<String, WebElement>> mobileFindByFunctionMap = new EnumMap<>(MobileFindBy.class);
	public final Function<String,WebElement> findByXpath = mobileElement -> DriverManager.getDriver().findElement(By.xpath(MobileFindBy.XPATH.toString()));
	public final Function<String, WebElement> findByCss =  mobileElement -> DriverManager.getDriver().findElement(By.cssSelector(MobileFindBy.CSS.toString()));
	public final Function<String, WebElement> findById = mobileElement -> DriverManager.getDriver().findElement(By.id(MobileFindBy.ID.toString()));
	//public final Function<String, WebElement> findByName = mobileElement -> DriverManager.getDriver().findElement(By.name(MobileFindBy.NAME.toString()));
	public final Function<String, WebElement> findByAccessibilityId = mobileElement -> DriverManager.getDriver().findElement(By.id(MobileFindBy.ACCESSIBILITY_ID.toString()));
	public final Function<String, WebElement> findByClassName = mobileElement -> DriverManager.getDriver().findElement(By.className(MobileFindBy.CLASS.toString()));
	public final Function<String, WebElement> findByResourceId = mobileElement -> DriverManager.getDriver().findElement(By.className(MobileFindBy.RESOURCE_ID.toString()));
	
	
	public ScreenActions() {
		PageFactory.initElements(DriverManager.getDriver(), this);
	}
	

	public WebElement getMobileElement(String mobileElement, MobileFindBy mobileFindBy) {
		if (mobileFindByFunctionMap.isEmpty()) {
			mobileFindByFunctionMap.put(XPATH, findByXpath);
			mobileFindByFunctionMap.put(CSS, findByCss);
			mobileFindByFunctionMap.put(ID, findById);
			mobileFindByFunctionMap.put(ACCESSIBILITY_ID, findByAccessibilityId);
			mobileFindByFunctionMap.put(CLASS, findByClassName);
			mobileFindByFunctionMap.put(RESOURCE_ID, findByResourceId);
		}
		return mobileFindByFunctionMap.get(mobileFindBy).apply(mobileElement);
	}

	public WebElement getDynamicMobileElement(String mobileElement, MobileFindBy mobileFindBy) {
		if (mobileFindBy == XPATH) {
			return DriverManager.getDriver().findElement(By.xpath(mobileElement));
		} else if (mobileFindBy == MobileFindBy.CSS) {
			return DriverManager.getDriver().findElement(By.cssSelector(mobileElement));
		}
		return null;
	}
	
	public List<WebElement> getDynamicMobileElements(String mobileElement, MobileFindBy mobileFindBy) {
		if (mobileFindBy == XPATH) {
			return DriverManager.getDriver().findElements(By.xpath(mobileElement));
		} else if (mobileFindBy == MobileFindBy.CSS) {
			return DriverManager.getDriver().findElements(By.cssSelector(mobileElement));
		}
		return null;
	}

	public void waitForPageLoad(int waitTime) {
		//DriverManager.getDriver().manage().timeouts().pageLoadTimeout(waitTime, TimeUnit.SECONDS);
		DriverManager.getDriver().manage().timeouts().pageLoadTimeout(Duration.ofSeconds(waitTime));

	}

	public String getTextFromAttribute(WaitStrategy waitStrategy, WebElement element) {
		return explicitlyWaitForElement(waitStrategy, element).getAttribute("text");
	}

	public String getText(WebElement element, WaitStrategy waitStrategy) {
		return explicitlyWaitForElement(waitStrategy, element).getText();
	}

	public boolean isElementDisplayed(WebElement element) {
		return element.isDisplayed();
	}

	public void doClear(WebElement element) {
		element.clear();
	}

	public String getElementAttribute(WebElement element, String attributeName) {
		return element.getAttribute(attributeName);
	}

	public boolean isElementSelected(WebElement element) {
		return element.isSelected();
	}

	public boolean isElementEnabled(WebElement element) {
		return element.isEnabled();
	}

	public WebElement getActiveElement() {
		return DriverManager.getDriver().switchTo().activeElement();
	}

	public void moveMouseToElement(WebElement element, int xoffset, int yoffset) {
		new Actions(DriverManager.getDriver())
		.moveToElement(element, xoffset, yoffset)
		.perform();
		ExtentReportLogger.logInfo("Move to target element :" + element);
	}

	public void doubleClickOnElement(WebElement element) {
		new Actions(DriverManager.getDriver())
		.moveToElement(element)
		.doubleClick()
		.perform();
		ExtentReportLogger.logInfo("Double click on element : " + element);
	}
	/*
  protected void performSingleTap(WebElement element) {
    new Actions(DriverManager.getDriver())
      .singleTap(element)
      .perform();
    ExtentReportLogger.logInfo("Single tap on element : " + element);
  }
	 */

	public void performSingleTap(WebElement element) {

		Point location = element.getLocation();
		Dimension size = element.getSize();

		Point centerOfElement = getCenterOfElement(location, size);

		PointerInput finger1 = new PointerInput(PointerInput.Kind.TOUCH, "finger1");
		Sequence sequence = new Sequence(finger1, 1)
				.addAction(finger1.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), centerOfElement.x, centerOfElement.y))
				.addAction(finger1.createPointerDown(PointerInput.MouseButton.LEFT.asArg()))
				.addAction(new Pause(finger1, Duration.ofMillis(200)))
				.addAction(finger1.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));

		DriverManager.getDriver().perform(Collections.singletonList(sequence));
	}

	public Point getCenterOfElement(Point location, Dimension size) {
		return new Point(location.getX() + size.getWidth() / 2,
				location.getY() + size.getHeight() / 2);
	}
	/*
	  protected void performDoubleTap(WebElement element) {
	    new TouchActions(DriverManager.getDriver())
	      .doubleTap(element)
	      .perform();
	    ExtentReportLogger.logInfo("Double tap on element : " + element);
	  }
	 */

	public void performDoubleTap(WebElement element) {

		Point location = element.getLocation();
	    Dimension size = element.getSize();

	    Point centerOfElement = getCenterOfElement(location, size);

	    PointerInput finger1 = new PointerInput(PointerInput.Kind.TOUCH, "finger1");
	    Sequence sequence = new Sequence(finger1, 1)
	        .addAction(finger1.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(),
	        		centerOfElement.x, centerOfElement.y))
	        .addAction(finger1.createPointerDown(PointerInput.MouseButton.LEFT.asArg()))
	        .addAction(new Pause(finger1, Duration.ofMillis(100)))
	        .addAction(finger1.createPointerUp(PointerInput.MouseButton.LEFT.asArg()))
	        .addAction(new Pause(finger1, Duration.ofMillis(100)))
	        .addAction(finger1.createPointerDown(PointerInput.MouseButton.LEFT.asArg()))
	        .addAction(new Pause(finger1, Duration.ofMillis(100)))
	        .addAction(finger1.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));

	    DriverManager.getDriver().perform(Collections.singletonList(sequence));

	}

	/*
	protected void performLongTap(WebElement element) {
		new TouchActions(DriverManager.getDriver())
		.longPress(element)
		.perform();
		ExtentReportLogger.logInfo("Long press on element : " + element);
	}
	*/
	
	public void performLongTapOrPress(WebElement element) {
		
		Point location = element.getLocation();
	    Dimension size = element.getSize();

	    Point centerOfElement = getCenterOfElement(location, size);

	    PointerInput finger1 = new PointerInput(PointerInput.Kind.TOUCH, "finger1");
	    Sequence sequence = new Sequence(finger1, 1)
	        .addAction(finger1.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(),
	        		centerOfElement.x, centerOfElement.y))
	        .addAction(finger1.createPointerDown(PointerInput.MouseButton.LEFT.asArg()))
	        .addAction(new Pause(finger1, Duration.ofSeconds(2)))
	        .addAction(finger1.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));

	    DriverManager.getDriver().perform(Collections.singletonList(sequence));
	}
	/*
	protected void touchScreenScroll(WebElement element, int x, int y) {
		new TouchActions(DriverManager.getDriver())
		.scroll(element, x, y)
		.perform();
	}
	*/
	
	/*
	protected void scrollClickAndroid(String scrollableListId, String selectionText) {
		
		DriverManager.getDriver().findElementByAndroidUIAutomator(
				"new UiScrollable(new UiSelector().scrollable(true)."
						+ "resourceId(\"" + scrollableListId + "\"))"
						+ ".setAsHorizontalList().scrollIntoView(new UiSelector().text(\"" + selectionText + "\"))").click();
	}
	
	*/
	public void click(WebElement element, String elementName) {
		try {
			element.click();
			ExtentReportLogger.logInfo("Clicked on " + elementName);
		} catch (Exception e) {
			ExtentReportLogger.logFail("Exception occurred when clicking on - " + elementName, e);
		}
	}

	public void click(String element, MobileFindBy elementType, String elementName) {
		click(getMobileElement(element, elementType), elementName);
	}

	public void enterText(WebElement element, String value, String elementName) {
		try {
			explicitlyWaitForElement(WaitStrategy.VISIBLE, element);
			doClear(element);
			element.sendKeys(value);
			ExtentReportLogger.logInfo("Entered value - <b>" + value + "</b> in the field " + elementName);
		} catch (Exception e) {
			ExtentReportLogger.logFail("Exception occurred while entering value in the field - " + elementName, e);
		}
	}

	public void enterValueAndPressEnter(WebElement element, String value, String elementName) {
		try {
			doClear(element);
			element.sendKeys(value, Keys.ENTER);
			ExtentReportLogger.logInfo("Entered value - <b>" + value + "</b> in the field " + elementName + " and pressed enter");
		} catch (Exception e) {
			ExtentReportLogger.logFail("Exception caught while entering value", e);
		}
	}

	public void enter(String element, MobileFindBy elementType, String value, String elementName) {
		enterText(getMobileElement(element, elementType), value, elementName);
	}

	public boolean isTextPresent(String containsText) {
		return DriverManager.getDriver().getPageSource().contains(containsText);
	}
	
	public void navigateBack() {
		DriverManager.getDriver().navigate().back();
		ExtentReportLogger.logInfo("Navigated back");
	}

	public void powerStateAndroid(String powerState) {
		switch (powerState) {
		case "ON":
			((AndroidDriver) DriverManager.getDriver()).setPowerAC(PowerACState.ON);
			break;
		case "OFF":
			((AndroidDriver) DriverManager.getDriver()).setPowerAC(PowerACState.OFF);
			break;
		default:
			ExtentReportLogger.warning("Voice state not available");
			break;
		}
	}

	/**
	 * Swipe Down
	 */
	public void swipeDown() {
		DriverManager.getDriver().executeScript("mobile:scroll",
				ImmutableMap.of("direction", "down"));
		ExtentReportLogger.logInfo("Swipe Down");
	}

	/**
	 * Swipe Up
	 */
	public void swipeUP() {
		DriverManager.getDriver().executeScript("mobile:scroll", ImmutableMap.of("direction", "up"));
		ExtentReportLogger.logInfo("Swipe Up");
	}

	/**
	 * Accept Alert
	 */
	public void acceptAlert() {
		DriverManager.getDriver().executeScript("mobile:acceptAlert");
		ExtentReportLogger.logInfo("Accept Alert");
	}

	/**
	 * Dismiss Alert
	 */
	public void dismissAlert() {
		DriverManager.getDriver().executeScript("mobile:dismissAlert");
		ExtentReportLogger.logInfo("Dismiss Alert");
	}

	/**
	 * Long press key
	 *
	 * @param element element
	 */
	/*
	public void longPress(MobileElement element) {
		try {
			new TouchAction<>(DriverManager.getDriver())
			.longPress(ElementOption.element(element))
			.perform();
		} catch (Exception e) {
			ExtentReportLogger.logFail("Exception caught while performing long press on the Mobile Element", e);
		}
	}
	*/
	/**
	 * Scroll to specific location
	 */
	public void scrollToLocation() {
		try {
			HashMap<String, Double> scrollElement = new HashMap<>();
			scrollElement.put("startX", 0.50);
			scrollElement.put("startY", 0.95);
			scrollElement.put("endX", 0.50);
			scrollElement.put("endY", 0.01);
			scrollElement.put("duration", 3.0);
			DriverManager.getDriver().executeScript("mobile: swipe", scrollElement);
		} catch (Exception e) {
			ExtentReportLogger.logFail("Exception caught when scrolling to specific location", e);
		}
	}
	
	public void scrollToElement(WebElement element) {
		try {
			HashMap<String, String> scrollObject = new HashMap<>();
			scrollObject.put("element", ((RemoteWebElement) element).getId());
			DriverManager.getDriver().executeScript("mobile:scroll", scrollObject);
		} catch (Exception e) {
			ExtentReportLogger.logFail("Exception caught when scrolling to element", e);
		}
	
	}
	
	
	public boolean checkListIsSorted(List<String> listToSort) {
		if (!listToSort.isEmpty()) {
			try {
				if (Ordering.natural().isOrdered(listToSort)) {
					ExtentReportLogger.logPass("List is sorted");
					return true;
				} else {
					ExtentReportLogger.logInfo("List is not sorted");
					return false;
				}
			} catch (Exception e) {
				ExtentReportLogger.logFail("Exception caught when checking if list is sorted", e);
			}
		} else {
			ExtentReportLogger.warning("List is empty");
		}
		return false;
	}

	/**
	 * Touch Actions
	 *
	 * @param a1   axis 1
	 * @param b1   axis 2
	 * @param a2   axis 3
	 * @param b2   axis 4
	 * @param time time
	 */
	/*
	@SuppressWarnings("rawtypes")
	private void touchActions(int a1, int b1, int a2, int b2, int time) {
		TouchAction touchAction = new TouchAction(DriverManager.getDriver());
		touchAction.press(PointOption.point(a1, b1)).
		waitAction(WaitOptions.waitOptions(Duration.ofMillis(time))).
		moveTo(PointOption.point(a2, b2)).release();
		touchAction.perform();
	}
	*/
	public void touchActions(int a1, int b1, int a2, int b2, int time) {
		
		PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
		Sequence swipe = new Sequence(finger, 1);
		swipe.addAction(finger.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), a1, b1));
		swipe.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
		swipe.addAction(new Pause(finger, Duration.ofMillis(time)));
		swipe.addAction(finger.createPointerMove(Duration.ofMillis(1000), PointerInput.Origin.viewport(), a2, b2));
		swipe.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
		DriverManager.getDriver().perform(Collections.singletonList(swipe));
		ExtentReportLogger.logInfo("Swipe from : " + a1 + " and " + b1 + " to " + a2 + " and " + b2);
		
	}
	
	
	/**
	 * Swipe with axix
	 *
	 * @param x    x axis
	 * @param y    y axis
	 * @param x1   x1 axis
	 * @param y1   y1 axis
	 * @param time timeInMilli
	 */
	public void swipeAxis(int x, int y, int x1, int y1, int count, int time) {
		for (int i = 0; i < count; i++) {
			touchActions(x, y, x1, y1, time);
		}
	}

	/**
	 * tap to element for 250sec
	 *
	 * @param androidElement element
	 */
	/*
	@SuppressWarnings("rawtypes")
	public void tapByElement(MobileElement androidElement) {
		new TouchAction(DriverManager.getDriver())
		.tap(TapOptions.tapOptions().withElement(ElementOption.element(androidElement)))
		.waitAction(WaitOptions.waitOptions(Duration.ofMillis(250))).perform();
	}
	*/
	/**
	 * Tap by coordinates
	 *
	 * @param x x
	 * @param y y
	 */
	/*
	@SuppressWarnings("rawtypes")
	public void tapByCoordinates(int x, int y) {
		new TouchAction(DriverManager.getDriver())
		.tap(PointOption.point(x, y))
		.waitAction(WaitOptions.waitOptions(Duration.ofMillis(250))).perform();
	}
	*/
	public void tapByCoordinates(int x, int y) {
		PointerInput finger = new PointerInput(PointerInput.Kind.TOUCH, "finger");
		Sequence tap = new Sequence(finger, 1);
		tap.addAction(finger.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), x, y));
		tap.addAction(finger.createPointerDown(PointerInput.MouseButton.LEFT.asArg()));
		tap.addAction(new Pause(finger, Duration.ofMillis(250)));
		tap.addAction(finger.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));
		DriverManager.getDriver().perform(Collections.singletonList(tap));
		ExtentReportLogger.logInfo("Tap on coordinates : " + x + " and " + y);
	}
	
	/**
	 * Press by element
	 *
	 * @param element element
	 * @param seconds time
	 */
	/*
	@SuppressWarnings("rawtypes")
	public void pressByElement(MobileElement element, long seconds) {
		new TouchAction(DriverManager.getDriver())
		.press(ElementOption.element(element))
		.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(seconds)))
		.release()
		.perform();
	}
	*/
	
	/**
	 * LongPress by element
	 *
	 * @param element element
	 * @param seconds time
	 */
	/*
	@SuppressWarnings("rawtypes")
	public void longPressByElement(MobileElement element, long seconds) {
		new TouchAction(DriverManager.getDriver())
		.longPress(ElementOption.element(element))
		.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(seconds)))
		.release()
		.perform();
	}
	*/
	public void longPressByElement(WebElement element) {
		
		new Actions(DriverManager.getDriver()).clickAndHold(element).perform();
		ExtentReportLogger.logInfo("Long press on element : " + element);
	}
	
	/**
	 * Press by co-ordinates
	 *
	 * @param x       x
	 * @param y       y
	 * @param seconds time
	 */
	/*
	@SuppressWarnings("rawtypes")
	public void pressByCoordinates(int x, int y, long seconds) {
		new TouchAction(DriverManager.getDriver())
		.press(PointOption.point(x, y))
		.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(seconds)))
		.release()
		.perform();
	}
	*/
	/**
	 * Horizontal swipe by percentage
	 *
	 * @param startPercentage  start
	 * @param endPercentage    end
	 * @param anchorPercentage anchor
	 */
	//@SuppressWarnings("rawtypes")
	public void horizontalSwipeByPercentage(double startPercentage, double endPercentage, double anchorPercentage) {
		Dimension size = DriverManager.getDriver().manage().window().getSize();
		int anchor = (int) (size.height * anchorPercentage);
		int startPoint = (int) (size.width * startPercentage);
		int endPoint = (int) (size.width * endPercentage);
		/*
		new TouchAction(DriverManager.getDriver())
		.press(PointOption.point(startPoint, anchor))
		.waitAction(WaitOptions.waitOptions(Duration.ofMillis(1000)))
		.moveTo(PointOption.point(endPoint, anchor))
		.release().perform();
		*/
		touchActions(startPoint, anchor, endPoint, anchor, 1000);
		ExtentReportLogger.logInfo("Horizontal swipe by percentage");
	}

	/**
	 * Vertical swipe by percentage
	 *
	 * @param startPercentage  start
	 * @param endPercentage    end
	 * @param anchorPercentage anchor
	 */
	//@SuppressWarnings("rawtypes")
	public void verticalSwipeByPercentages(double startPercentage, double endPercentage, double anchorPercentage) {
		Dimension size = DriverManager.getDriver().manage().window().getSize();
		int anchor = (int) (size.width * anchorPercentage);
		int startPoint = (int) (size.height * startPercentage);
		int endPoint = (int) (size.height * endPercentage);
		/*
		new TouchAction(DriverManager.getDriver())
		.press(PointOption.point(anchor, startPoint))
		.waitAction(WaitOptions.waitOptions(Duration.ofMillis(1000)))
		.moveTo(PointOption.point(anchor, endPoint))
		.release().perform();
		*/
		touchActions(anchor, startPoint, anchor, endPoint, 1000);
		ExtentReportLogger.logInfo("Vertical swipe by percentage");
	}

	/**
	 * Swipe by elements
	 *
	 * @param startElement start
	 * @param endElement   end
	 */
	//@SuppressWarnings("rawtypes")
	public void swipeByElements(WebElement startElement, WebElement endElement) {
		int startX = startElement.getLocation().getX() + (startElement.getSize().getWidth() / 2);
		int startY = startElement.getLocation().getY() + (startElement.getSize().getHeight() / 2);

		int endX = endElement.getLocation().getX() + (endElement.getSize().getWidth() / 2);
		int endY = endElement.getLocation().getY() + (endElement.getSize().getHeight() / 2);
		/*
		new TouchAction(DriverManager.getDriver())
		.press(PointOption.point(startX, startY))
		.waitAction(WaitOptions.waitOptions(Duration.ofMillis(1000)))
		.moveTo(PointOption.point(endX, endY))
		.release().perform();
		*/
		touchActions(startX, startY, endX, endY, 1000);
	}

	/**
	 * Multi touch by element
	 *
	 * @param androidElement element
	 */
	/*
	@SuppressWarnings("rawtypes")
	public void multiTouchByElement(MobileElement androidElement) {
		TouchAction press = new TouchAction(DriverManager.getDriver())
				.press(ElementOption.element(androidElement))
				.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1)))
				.release();

		new MultiTouchAction(DriverManager.getDriver())
		.add(press)
		.perform();
	}
	*/

	/**
	 * Swipe touch (UP,DOWN,LEFT,RIGHT)
	 *
	 * @param direction direction
	 * @param count     count
	 */
	public void swipe(String direction, int count, int time) {
		Dimension size = DriverManager.getDriver().manage().window().getSize();
		try {
			switch (direction) {
			case "left":
			case "LEFT":
				for (int i = 0; i < count; i++) {
					int startx = (int) (size.width * 0.8);
					int endx = (int) (size.width * 0.20);
					int starty = size.height / 2;
					touchActions(startx, starty, endx, starty, time);
				}
				break;
			case "right":
			case "RIGHT":
				for (int j = 0; j < count; j++) {
					int endx = (int) (size.width * 0.8);
					int startx = (int) (size.width * 0.20);
					int starty = size.height / 2;
					touchActions(startx, starty, endx, starty, time);
				}
				break;
			case "up":
			case "UP":
				for (int j = 0; j < count; j++) {
					int starty = (int) (size.height * 0.80);
					int endy = (int) (size.height * 0.20);
					int startx = size.width / 2;
					touchActions(startx, starty, startx, endy, time);
				}
				break;
			case "down":
			case "DOWN":
				for (int j = 0; j < count; j++) {
					int starty = (int) (size.height * 0.80);
					int endy = (int) (size.height * 0.20);
					int startx = size.width / 2;
					touchActions(startx, endy, startx, starty, time);
				}
				break;
			default:
				ExtentReportLogger.logInfo("Direction not found");
				break;
			}
		} catch (Exception e) {
			ExtentReportLogger.logFail("Exception caught while performing Swipe", e);
		}
	}

	public void zoom(WebElement element) {
		
		Point centerOfElement = getCenterOfElement(element.getLocation(), element.getSize());

	    PointerInput finger1 = new PointerInput(PointerInput.Kind.TOUCH, "finger1");
	    PointerInput finger2 = new PointerInput(PointerInput.Kind.TOUCH, "finger2");
	    Sequence sequence = new Sequence(finger1, 1)
	        .addAction(finger1.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), centerOfElement.x, centerOfElement.y))
	        .addAction(finger1.createPointerDown(PointerInput.MouseButton.LEFT.asArg()))
	        .addAction(new Pause(finger1, Duration.ofMillis(200)))
	        .addAction(finger1.createPointerMove(Duration.ofMillis(200),
	                                             PointerInput.Origin.viewport(), centerOfElement.getX() + 100,
	                                             centerOfElement.getY() - 100))
	        .addAction(finger1.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));

	    Sequence sequence2 = new Sequence(finger2, 1)
	        .addAction(finger2.createPointerMove(Duration.ZERO, PointerInput.Origin.viewport(), centerOfElement.x,centerOfElement.y))
	        .addAction(finger2.createPointerDown(PointerInput.MouseButton.LEFT.asArg()))
	        .addAction(new Pause(finger2, Duration.ofMillis(200)))
	        .addAction(finger2.createPointerMove(Duration.ofMillis(200),
	                                             PointerInput.Origin.viewport(), centerOfElement.getX() - 100,
	                                             centerOfElement.getY() + 100))
	        .addAction(finger2.createPointerUp(PointerInput.MouseButton.LEFT.asArg()));

	    DriverManager.getDriver().perform(Arrays.asList(sequence, sequence2));
        
    }
		


}
