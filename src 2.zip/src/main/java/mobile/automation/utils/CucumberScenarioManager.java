package mobile.automation.utils;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.plugin.ConcurrentEventListener;
import io.cucumber.plugin.event.*;
import com.aventstack.extentreports.Status;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import mobile.automation.utils.screencapture.*;
import mobile.automation.constants.FrameworkConstants;
import mobile.automation.enums.ConfigProperties;
import mobile.automation.reports.*;
import mobile.automation.utils.configloader.*;

import java.io.File;


public class CucumberScenarioManager implements ConcurrentEventListener {
    static Scenario scenario;
    public static String stepName;
    public static ScreenRecordingService videoRecorder = null;
    static String path = FrameworkConstants.SCREENSHOT_PATH;
    static File baseScreenshotDir = new File(path);
    public static Logger logger = LogManager.getLogger(CucumberScenarioManager.class);

    private static Scenario getCurrentScenario() {
        return scenario;
    }

    /**
     * @param scenario
     * @Description: This method identifies current scenario which is running and sets it to scenario variable
     */
    @Before(order = 0)
    public static void setRunningScenario(Scenario scenario) throws Exception {

        CucumberScenarioManager.scenario = scenario;
        ExtentReportManager.createTest(scenario.getName());
        if (PropertyUtils.getPropertyValue(ConfigProperties.RECORD_SCREEN).equals("yes")) {
        	ScreenRecordingService.startRecording();
            /*
            commenting the code of video recording using monte library as data loss is observed with this implementation.
            */
            //videoRecorder = ScreenVideoRecorder.startScreenRecording();
        }
    }

    /**
     * @return : Returns string current running feature file name
     * @Description: This method gets scenario detail from getCurrentScenario method and then extract feature name.
     */
    public static String getRunningFeatureFileName() {
        String featureFilename;
        featureFilename = getCurrentScenario().getUri().toString();
        String[] test = featureFilename.split("/");
        String[] FeatureName = test[test.length - 1].split("\\.");
        return FeatureName[0];
    }

    public static String getCurrentFeatureDirectory(String featurename) {
        String directoryPath = null;
        if (!baseScreenshotDir.isDirectory()) {
            baseScreenshotDir.mkdir();
            path = baseScreenshotDir.getPath().concat("\\");
            logger.info("Base Screenshot directory created" + baseScreenshotDir.getPath());
        }
        File currentFeatureFolder = new File(path + featurename);
        if (!currentFeatureFolder.isDirectory()) {
            currentFeatureFolder.mkdir();
            directoryPath = currentFeatureFolder.getPath().concat("\\");
            logger.info("Current feature's directory created" + currentFeatureFolder.getPath());
            return directoryPath;
        } else {
            directoryPath = currentFeatureFolder.getPath().concat("\\");
            return directoryPath;
        }

    }

    /**
     * @return : Returns string scenario name
     * @Description: This method gets scenario detail from getCurrentScenario method and then extract scenario name by replacing special characters.
     */
    public static String getRunningScenarioName() {
        String scenarioName = getCurrentScenario().getName();
        scenarioName = scenarioName.replaceAll("[^a-zA-Z0-9]", "");
        return scenarioName;
    }

    /**
     * @param scenario
     * @return Returns string current running feature file name
     * @Description: This method is used to extract feature name from explicitly provided scenario object.
     */
    public static String getFeatureFileNameFromScenarioId(Scenario scenario) {
        String featureName = "Feature ";
        String rawFeatureName = scenario.getId().split(";")[0].replace("-", " ");
        featureName = featureName + rawFeatureName.substring(0, 1).toUpperCase() + rawFeatureName.substring(1);
        return featureName;
    }

    public static Status getScenarioStatus() {
        if (getCurrentScenario().isFailed()) {
            return Status.FAIL;
        } else {
            return Status.PASS;
        }
    }

    public EventHandler<TestStepStarted> stepHandler = new EventHandler<TestStepStarted>() {
        @Override
        public void receive(TestStepStarted event) {
            getStepNameDetails(event);
        }

    };

    @Override
    public void setEventPublisher(EventPublisher publisher) {
        publisher.registerHandlerFor(TestStepStarted.class, stepHandler);
    }

    /*
    @Description: Used to get the StepName.
    Parameter : 1. Pass the event of type TestStepStarted.
     */
    private void getStepNameDetails(TestStepStarted event) {
        if (event.getTestStep() instanceof PickleStepTestStep) {
            PickleStepTestStep testStep = (PickleStepTestStep) event.getTestStep();
            stepName = testStep.getStep().getText();
        }
    }

    @After()
    public void afterScenario() throws Exception {

        /*if (videoRecorder != null) {
            ScreenVideoRecorder.stopScreenRecording(videoRecorder);
            VideoRecorderAUT.stopRecording();
        }*/
    }
}
