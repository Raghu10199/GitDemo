package mobile.automation.utils.dataprovider;

import mobile.automation.constants.FrameworkConstants;
import mobile.automation.entity.SignUpData;
import mobile.automation.entity.ProductsData;
import mobile.automation.entity.TestData;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.testng.annotations.DataProvider;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class DataProviderUtils {

  private static List<Map<String, String>> list = new ArrayList<>();

  @DataProvider
  public static Object[][] getData(Method method) {
    SignUpData signupData;
    ProductsData productsData;
    TestData testData = null;
    String testName = method.getName();

    if (list.isEmpty())
      list = ExcelUtils.getTestDetails(FrameworkConstants.TEST_DATA_SHEET);

    List<Map<String, String>> smallList = new ArrayList<>(list);

    Predicate<Map<String, String>> isTestNameNotMatching = map -> !map.get("TestCaseName").equalsIgnoreCase(testName);

    smallList.removeIf(isTestNameNotMatching);
    
    

    for (Map<String, String> mapData : smallList) {
    	
    	/*

    	signupData = SignUpData.builder()
        .setcountry(mapData.get("country"))
        .setname(mapData.get("name"))
        .setgender(mapData.get("gender"))
        .build();

    	productsData = ProductsData.builder()
        .setSearchText(mapData.get("searchTerm"))
        .build();

      testData = TestData.builder()
        .setLoginData(loginData)
        .setSearchData(searchData)
        .build();
        */
    }
    
    
    return new Object[][] {
      {testData}
    };
 }
}	
