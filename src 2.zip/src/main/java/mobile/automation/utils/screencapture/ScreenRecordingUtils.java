package mobile.automation.utils.screencapture;

import mobile.automation.constants.FrameworkConstants;
import mobile.automation.driver.manager.DriverManager;
import io.appium.java_client.screenrecording.CanRecordScreen;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.apache.commons.codec.binary.Base64;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import io.qameta.allure.Allure;


@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class ScreenRecordingUtils {

  public static void startScreenRecording() {
    ((CanRecordScreen) DriverManager.getDriver()).startRecordingScreen();
  }

  public static void stopScreenRecording(String methodName) {
    var recordedVideoFile = ((CanRecordScreen) DriverManager.getDriver()).stopRecordingScreen();
    var pathToWriteVideoFile = FrameworkConstants.getScreenRecordingsPath() + File.separator + methodName + ".mp4";
    writeToOutputStream(pathToWriteVideoFile, recordedVideoFile);
    Allure.addAttachment("Screen Recording", "video/mp4", pathToWriteVideoFile, ".mp4");
    
  }

  static void writeToOutputStream(String filePathToWrite, String recordedVideoFile) {
    try (FileOutputStream outputStream = new FileOutputStream(filePathToWrite)) {
      outputStream.write(Base64.decodeBase64(recordedVideoFile));
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}
