package mobile.automation.utils.screencapture;

import mobile.automation.constants.FrameworkConstants;
import mobile.automation.driver.manager.DriverManager;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.SneakyThrows;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import java.io.File;
import java.io.IOException;
import io.qameta.allure.Allure;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class ScreenshotUtils {

  // This class is to handle the change in third party library
  @SneakyThrows
  public static void captureScreenshotAsFile(String testName) throws IOException {
    File source = ((TakesScreenshot) DriverManager.getDriver()).getScreenshotAs(OutputType.FILE);
    File destination = new File(FrameworkConstants.SCREENSHOT_PATH + File.separator + testName + ".png");
    FileUtils.copyFile(source, destination);
    //Allure.addAttachment("Screenshot", FileUtils.openInputStream(destination));
  }

  public static String captureScreenshotAsBase64() {
    return ((TakesScreenshot) DriverManager.getDriver()).getScreenshotAs(OutputType.BASE64);
  }
}
