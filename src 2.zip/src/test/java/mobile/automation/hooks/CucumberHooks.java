package mobile.automation.hooks;

import io.cucumber.java.After;
import io.cucumber.java.AfterAll;
import io.cucumber.java.AfterStep;
import io.cucumber.java.BeforeAll;
import io.cucumber.java.DefaultParameterTransformer;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.testng.ITestResult;
import org.testng.annotations.Optional;
import io.qameta.allure.Allure;

import io.cucumber.java.*;
import java.util.Objects;
import mobile.automation.driver.factory.DriverFactory;
import mobile.automation.driver.manager.DeviceManager;
import mobile.automation.driver.manager.DriverManager;
import mobile.automation.driver.manager.PlatformManager;
import mobile.automation.enums.MobilePlatformName;
import mobile.automation.utils.AppiumServerManager;
import mobile.automation.utils.screencapture.*;
import mobile.automation.reports.*;

public class CucumberHooks {
	
	public CucumberHooks() {
		// Constructor
	}
	
	@BeforeAll
	public void beforeAll() {
	    AppiumServerManager.startAppiumServer();
	  }
	
	@ParameterType(".*")	
	@Before
	public void before(String platformName, String udid, String deviceName, @Optional("androidOnly") String systemPort,
            @Optional("androidOnly") String chromeDriverPort, @Optional("androidOnly") String emulator,
            @Optional("iOSOnly") String wdaLocalPort, @Optional("iOSOnly") String webkitDebugProxyPort) {
			PlatformManager.setPlatformName(platformName);
			DeviceManager.setDeviceName(deviceName);
			if (Objects.isNull(DriverManager.getDriver())) {
				DriverFactory.initializeDriver(MobilePlatformName.valueOf(platformName.toUpperCase()), deviceName, udid,
			                          Integer.parseInt(systemPort), emulator);
			}
			ScreenRecordingService.startRecording();
		
	}
	
	@BeforeStep
	public void beforeStep(String stepName) {
		Allure.step("Step: " + stepName);
		Allure.addAttachment("Step: ", stepName);
		
		
	}
	
	@AfterStep
	public void afterStep() {
	
		
	}

	
	@After
	public void after(ITestResult result) {
	    ScreenRecordingService.stopRecording(result.getName());
	    DriverFactory.quitDriver();
	}
	
	@AfterAll
	public void afterAll() {
	    AppiumServerManager.stopAppiumServer();
	}
			
}

	
