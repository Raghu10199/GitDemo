package mobile.automation.runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import org.testng.annotations.DataProvider;

@CucumberOptions(tags = "not (@Skip)", features = {"src/test/resources/features/"},
glue = {"mobile.automation.steps","mobile.automation.utils","mobile.automation.hooks"},
plugin = {"pretty","mobile.automation.utils.CucumberScenarioManager","rerun:target/failedrerun1.txt","json:target/cucumber.json"}
)

public class CucumberRunner extends AbstractTestNGCucumberTests {
	
	@Override
	@DataProvider(parallel = true)
	public Object[][] scenarios() {
		return super.scenarios();
	}

}
