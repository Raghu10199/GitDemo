package mobile.automation.runner;

import org.testng.annotations.DataProvider;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(tags = "not (@Skip)", features = {"src/test/resources/features/"},
		glue = {"ui.automation.steps","mobile.automation.utils","mobile.automation.hooks"},
		plugin = { "pretty", "mobile.automation.utils.CucumberScenarioManager", "io.qameta.allure.cucumber7jvm.AllureCucumber7Jvm" }
)

public class FailedScenarioRunner1 extends AbstractTestNGCucumberTests {

    @Override
    @DataProvider(parallel = true)
    public Object[][] scenarios() {
        return super.scenarios();
    }

}


