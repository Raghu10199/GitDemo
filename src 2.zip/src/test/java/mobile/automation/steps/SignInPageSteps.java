package mobile.automation.steps;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.After;
import io.qameta.allure.Allure;
import org.apache.commons.io.FileUtils;
//import org.monte.screenrecorder.ScreenRecorder;

//import ui.automation.manager.ElementAsserts;
//import ui.automation.page.LoginPage;
//import ui.automation.utils.ActiveBrowser;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
//import org.apache.pdfbox.pdmodel.PDStructureElementNameTreeNode;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import mobile.automation.Screens.*;
import mobile.automation.driver.manager.DriverManager;
//import ui.automation.utils.ActiveBrowser;
import mobile.automation.utils.screencapture.*;
import mobile.automation.reports.*;
//import ui.automation.utils.Screenshot;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

public class SignInPageSteps {
    public Logger logger = LogManager.getLogger(SignInPageSteps.class);
    WebDriver driver = DriverManager.getDriver();
    SignUpScreen signupscreen = new SignUpScreen();
    
    
    @Before
    @Given("Mobile Application is launched")
    public void launch_Web_Application() throws Exception {
    	ExtentReportLogger.logInfo("Mobile Application is launched");
    }

    @When("SignIn Screen is displayed")
    public void signIn_screen_displayed() {
        signupscreen.isSignUpScreenDisplayed();
    }

    @Then("Select country from country dropdown")
    public void select_country() {
    	signupscreen.selectCountry("Argentina");
    }

    @And("Enter User Name")
    public void enter_user_name() {
    	signupscreen.enterName("TestUser");
    }

    @And("Select gender")
    public void select_gender() {
    	signupscreen.selectGender("Male");
    }

    @And("Click the Lets Shop btn")
    public void click_lets_shop_btn() {
         signupscreen.clickLetsShop();
    }
    
    
    
}