package mobile.automation.test;

import org.testng.annotations.Test;

import mobile.automation.Screens.ProductsScreen;
import mobile.automation.base.BaseTest;
import mobile.automation.customannotations.FrameworkAnnotation;
import mobile.automation.enums.CategoryType;

public class AddProductTest extends BaseTest{
	
	ProductsScreen productsScreen;
	// SignUpScreen signUpScreen;

	@FrameworkAnnotation(author = { "Soma" }, category = { CategoryType.SMOKE })
	@Test
	public void testAddProduct() {
        productsScreen = new ProductsScreen();
        
        productsScreen.isProductDisplayed("Air Jordan 4 Retro");
        //productsScreen.swipeToElementAndClick("Air Jordan 4 Retro");
        productsScreen.addProductToCart("Air Jordan 4 Retro");
        productsScreen.clickCart();
        
	}
        

}
