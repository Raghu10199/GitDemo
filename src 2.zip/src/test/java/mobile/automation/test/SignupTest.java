package mobile.automation.test;

import org.testng.annotations.Test;

import mobile.automation.Screens.ProductsScreen;
import mobile.automation.Screens.SignUpScreen;
import mobile.automation.base.BaseTest;
import mobile.automation.customannotations.FrameworkAnnotation;
import mobile.automation.enums.CategoryType;

public class SignupTest extends BaseTest {
	
	
	SignUpScreen signUpScreen;
	
	@FrameworkAnnotation(author = { "Soma" }, category = { CategoryType.SMOKE })
    @Test
	public void testSignup(){

	    signUpScreen = new SignUpScreen();  
	    signUpScreen.isSignUpScreenDisplayed();
	    signUpScreen.selectCountry("Armenia");
	    signUpScreen.enterName("Test User");
	    signUpScreen.selectGender("Male");
	    signUpScreen.clickLetsShop();
 
	}
	

}
